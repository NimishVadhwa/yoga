const joi = require('joi');
const field = require('../models/Form_feildModel');
const form_value = require('../models/Form_valueModel');
const category = require('../models/CategoryModel');

exports.add_form_column = async(req, res, next)=>{

    const schema = joi.object({
        cat_id: joi.string().required(),
        column : joi.array().required()
    });

    try {
        
        await schema.validateAsync(req.body);

        const check = await category.findOne({
            where: { id:req.body.cat_id,type:'form' }
        });

        if(!check) throw new Error('Category not found');

        req.body.column.forEach(async(element)=>{
            
            await field.create({
                label: element.label,
                column_name:element.column,
                column_type:element.type,
                category_id: req.body.cat_id
            });

        });


        return res.status(200).json({
            data: [],
            status: true,
            message: "Feilds added successfully"
        });


    } catch (err) {
        err.status = 404;
        next(err);
    }

}

exports.form_column_with_cat = async (req, res, next) => {

    const schema = joi.object({
        cat_id : joi.number().required()
    });

    try {
        
        await schema.validateAsync(req.params);

        const data = await field.findAll({
            where: { category_id : req.params.cat_id}
        });

        return res.status(200).json({
            data: data,
            status: true,
            message: "Form Feilds"
        });


    } catch (err) {
        err.status = 400;
        next(err);
    }

}

exports.block_field = async(req, res, next)=>{

    const schema = joi.object({
        field_id: joi.number().required(),
        block:joi.string().required().valid('0','1')
    });

    try {
        
        await schema.validateAsync(req.body);

        await field.update({is_block:req.body.block},{
            where:{id:req.body.field_id}
        });

        return res.status(200).json({
            data: [],
            status: true,
            message: "successfull"
        });


    } catch (err) {
        err.status = 400;
        next(err);
    }


}
