const joi = require('joi');
const user = require('../models/UserModel');
const category = require('../models/CategoryModel');
const team = require('../models/TeamModel');
const form_field = require('../models/Form_feildModel');
const form_value = require('../models/Form_valueModel');

exports.trainer_list = async(req,res, next)=>{
    
    

}
